
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity encoder is
    generic (
        N     : positive := 10;
        g_div : positive := 5_000_000
    );
    port (
        i_clk   : in  std_logic;
        i_rst_n : in  std_logic;
        i_a     : in  std_logic;
        i_b     : in  std_logic;
        o_leds  : out std_logic_vector(N-1 downto 0)
    );
end entity encoder;

architecture rtl of encoder is

    signal r_div : natural range 0 to g_div - 1;
    signal s_en  : std_logic;

    signal r_a_cur  : std_logic;
    signal r_a_prev : std_logic;
    signal s_a_rising  : std_logic;
    signal s_a_stable  : std_logic;
    signal s_a_falling : std_logic;

    signal r_b_cur  : std_logic;
    signal r_b_prev : std_logic;
    signal s_b_rising  : std_logic;
    signal s_b_stable  : std_logic;
    signal s_b_falling : std_logic;

    signal s_clockwise    : std_logic;
    signal s_cntclockwise : std_logic;

    signal r_cnt : unsigned(N-1 downto 0);

begin

    p_divider : process(i_clk, i_rst_n)
    begin
        if (i_rst_n = '0') then
            r_div <= 0;
            s_en  <= '0';
        elsif rising_edge(i_clk) then
            if (r_div = g_div - 1) then
                r_div <= 0;
                s_en  <= '1';
            else
                r_div <= r_div + 1;
                s_en  <= '0';
            end if;
        end if;
    end process p_divider;

    p_sample : process(i_clk, i_rst_n)
    begin
        if (i_rst_n = '0') then
            r_a_cur  <= '0';
            r_a_prev <= '0';
            r_b_cur  <= '0';
            r_b_prev <= '0';
        elsif rising_edge(i_clk) then
            if (s_en = '1') then
                r_a_prev <= r_a_cur;
                r_a_cur  <= i_a;
                r_b_prev <= r_b_cur;
                r_b_cur  <= i_b;
            end if;
        end if;
    end process p_sample;

    s_a_rising  <= r_a_cur and not r_a_prev;
    s_a_falling <= (not r_a_cur) and r_a_prev;

    s_b_rising  <= r_b_cur and not r_b_prev;
    s_b_falling <= (not r_b_cur) and r_b_prev;

    s_clockwise    <= (s_a_rising and not r_b_cur) or (s_a_falling and r_b_cur);
    s_cntclockwise <= (s_b_rising and not r_a_cur) or (s_b_falling and r_a_cur);

    p_cnt : process(i_clk, i_rst_n)
    begin
        if (i_rst_n = '0') then
            r_cnt <= (others => '0');
        elsif rising_edge(i_clk) then
            if (s_en = '1') then
                if (s_clockwise = '1') then
                    r_cnt <= r_cnt + 1;
                elsif (s_cntclockwise = '1') then
                    r_cnt <= r_cnt - 1;
                end if;
            end if;
        end if;
    end process p_cnt;

    o_leds <= std_logic_vector(r_cnt);

end architecture rtl;
