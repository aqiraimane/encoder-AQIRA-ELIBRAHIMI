

catch {quit -sim}

catch {vdel -lib work -all}
vlib work
vmap work work

vcom -2008 -work work encoder.vhd
vcom -2008 -work work encoder_tb.vhd

vsim -voptargs=+acc work.tb_encoder

view wave

add wave -divider "ENTREES"
add wave /tb_encoder/s_clk
add wave /tb_encoder/s_rst_n
add wave /tb_encoder/s_a
add wave /tb_encoder/s_b

add wave -divider "DIVISEUR"
add wave /tb_encoder/uut/r_div
add wave /tb_encoder/uut/s_en

add wave -divider "VOIE A"
add wave /tb_encoder/uut/r_a_cur
add wave /tb_encoder/uut/r_a_prev
add wave /tb_encoder/uut/s_a_rising
add wave /tb_encoder/uut/s_a_falling

add wave -divider "VOIE B"
add wave /tb_encoder/uut/r_b_cur
add wave /tb_encoder/uut/r_b_prev
add wave /tb_encoder/uut/s_b_rising
add wave /tb_encoder/uut/s_b_falling

add wave -divider "DIRECTION"
add wave /tb_encoder/uut/s_clockwise
add wave /tb_encoder/uut/s_cntclockwise

add wave -divider "COMPTEUR"
add wave -radix unsigned /tb_encoder/uut/r_cnt
add wave -radix unsigned /tb_encoder/s_leds

run 40 us

wave zoom full
