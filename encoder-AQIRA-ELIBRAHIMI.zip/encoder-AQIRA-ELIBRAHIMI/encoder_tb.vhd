
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_encoder is
end entity tb_encoder;

architecture sim of tb_encoder is
    constant C_CLK_PERIOD : time := 20 ns;
    constant C_DIV        : natural := 10;
    constant C_STEP       : time := 4 * C_DIV * C_CLK_PERIOD;

    signal s_clk   : std_logic := '0';
    signal s_rst_n : std_logic := '0';
    signal s_a     : std_logic := '0';
    signal s_b     : std_logic := '0';
    signal s_leds  : std_logic_vector(9 downto 0);

begin

    uut : entity work.encoder
        generic map (N => 10, g_div => C_DIV)
        port map (
            i_clk   => s_clk,
            i_rst_n => s_rst_n,
            i_a     => s_a,
            i_b     => s_b,
            o_leds  => s_leds
        );

    s_clk <= not s_clk after C_CLK_PERIOD / 2;

    stimulus : process
    begin
        wait for 10 * C_CLK_PERIOD;
        s_rst_n <= '1';
        wait for 5 * C_DIV * C_CLK_PERIOD;

        for i in 1 to 5 loop
            s_a <= '1'; wait for C_STEP;
            s_b <= '1'; wait for C_STEP;
            s_a <= '0'; wait for C_STEP;
            s_b <= '0'; wait for C_STEP;
        end loop;

        wait for 3 * C_DIV * C_CLK_PERIOD;

        assert unsigned(s_leds) = 10
            report "ERREUR sens horaire : valeur attendue = 10" severity error;

        report "Apres 5 tours horaires : " & integer'image(to_integer(unsigned(s_leds)));

        for i in 1 to 5 loop
            s_b <= '1'; wait for C_STEP;
            s_a <= '1'; wait for C_STEP;
            s_b <= '0'; wait for C_STEP;
            s_a <= '0'; wait for C_STEP;
        end loop;

        wait for 3 * C_DIV * C_CLK_PERIOD;

        assert unsigned(s_leds) = 0
            report "ERREUR sens anti-horaire : valeur attendue = 0" severity error;

        report "Apres 5 tours anti-horaires : " & integer'image(to_integer(unsigned(s_leds)));

        report "Simulation terminee";
        wait;
    end process stimulus;

end architecture sim;
